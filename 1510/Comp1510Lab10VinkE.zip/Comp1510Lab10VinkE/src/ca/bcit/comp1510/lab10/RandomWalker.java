package ca.bcit.comp1510.lab10;

public class RandomWalker {

    
    private int currentX;
    
    private int currentY;
    
    private int maxSteps;
    
    private int numSteps;
    
    private int bound;
    
    
    
    
    
    
    
    
    
    
}
